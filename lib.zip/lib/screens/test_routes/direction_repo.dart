import 'package:dio/dio.dart';

import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:irrish_driving/screens/test_routes/direction_model.dart';

class DirectionsRepository {
  static const String _baseUrl =
      'https://maps.googleapis.com/maps/api/directions/json?';

  final Dio _dio;

  DirectionsRepository({Dio? dio}) : _dio = dio ?? Dio();

  Future<Directions> getDirections({
    required LatLng origin,
    required LatLng destination,
  }) async {
    final response = await _dio.get(
      _baseUrl,
      queryParameters: {
        'origin': '${origin.latitude},${origin.longitude}',
        'destination': '${destination.latitude},${destination.longitude}',
        'key': "AIzaSyDSKDKk75O5ffvGqNfJpJJZ3SXoiP_MdZU",
      },
    );

    // Check if response is successful
    if (response.statusCode == 200) {
      print("Response Data ${response.data}");
      return Directions.fromMap(response.data);
    }
    return getDirections(origin: origin, destination: destination);
  }
}
