import 'package:flutter/material.dart';

const colorWhite = Colors.white;
const colorGreen = Colors.green;
const colorBlack = Colors.black;
const mainColor = Color(0xff00A79D);
const colorDark = Color(0xFF736F7F);
const redColor = Colors.red;
const ctcolor = Color(0xff00A79D);
const boxColor = Color(0xff96DBD7);
const blueColor = Colors.blue;
